uniform sampler2D DiffuseSampler0;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    fragColor = vec4(texture(DiffuseSampler0, texCoord).rgb, 1.0);
}
