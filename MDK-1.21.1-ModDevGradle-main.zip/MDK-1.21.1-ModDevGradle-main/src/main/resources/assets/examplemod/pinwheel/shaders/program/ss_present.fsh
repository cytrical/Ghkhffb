uniform sampler2D DiffuseDepthSampler;
uniform sampler2D TrailSampler;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    fragColor = vec4(texture(TrailSampler, texCoord).rgb, 1.0);
    gl_FragDepth = texture(DiffuseDepthSampler, texCoord).r;
}
