uniform sampler2D DiffuseSampler0;
uniform sampler2D PrevSampler;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec3 cur = texture(DiffuseSampler0, texCoord).rgb;
    vec3 prev = texture(PrevSampler, texCoord).rgb;
    // los pixeles se quedan y se van apagando
    fragColor = vec4(max(cur, prev * 0.88), 1.0);
}
