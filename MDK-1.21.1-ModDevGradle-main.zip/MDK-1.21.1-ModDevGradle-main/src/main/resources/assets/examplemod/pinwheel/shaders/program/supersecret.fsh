#include veil:space_helper

uniform sampler2D DiffuseSampler0;
uniform sampler2D DiffuseDepthSampler;

uniform float uMode;
uniform float uTime;
uniform float uFar;
uniform float uSpeed;
// filtro de color personalizado
uniform float uCHue;       // grados
uniform float uCSat;
uniform float uCContrast;
uniform float uCBright;
uniform vec3  uCTint;

in vec2 texCoord;
out vec4 fragColor;

vec2 RES;
vec2 PX;

vec3 tex(vec2 p) { return texture(DiffuseSampler0, p).rgb; }
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
float h1(float n) { return fract(sin(n * 91.345) * 43758.5453); }
float h2(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

vec3 hueShift(vec3 c, float a) {
    float cs = cos(a);
    float sn = sin(a);
    mat3 toYIQ = mat3(0.299, 0.596, 0.211, 0.587, -0.274, -0.523, 0.114, -0.322, 0.312);
    mat3 toRGB = mat3(1.0, 1.0, 1.0, 0.956, -0.272, -1.106, 0.621, -0.647, 1.703);
    vec3 yiq = toYIQ * c;
    yiq.yz = vec2(yiq.y * cs - yiq.z * sn, yiq.y * sn + yiq.z * cs);
    return toRGB * yiq;
}

vec3 sat(vec3 c, float s) { return mix(vec3(luma(c)), c, s); }

float bayer4(vec2 p) {
    ivec2 i = ivec2(mod(p, 4.0));
    int m[16] = int[16](0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5);
    return float(m[i.x + i.y * 4]) / 16.0;
}

vec2 snap(vec2 uv, float cell) {
    return (floor(uv * RES / cell) + 0.5) * cell / RES;
}

// Sobel sobre el color (0..1)
float sobel(vec2 uv) {
    vec3 tl = tex(uv + PX * vec2(-1.0, 1.0));
    vec3 t  = tex(uv + PX * vec2(0.0, 1.0));
    vec3 tr = tex(uv + PX * vec2(1.0, 1.0));
    vec3 l  = tex(uv + PX * vec2(-1.0, 0.0));
    vec3 r  = tex(uv + PX * vec2(1.0, 0.0));
    vec3 bl = tex(uv + PX * vec2(-1.0, -1.0));
    vec3 b  = tex(uv + PX * vec2(0.0, -1.0));
    vec3 br = tex(uv + PX * vec2(1.0, -1.0));
    vec3 gx = (tr + 2.0 * r + br) - (tl + 2.0 * l + bl);
    vec3 gy = (tl + 2.0 * t + tr) - (bl + 2.0 * b + br);
    return clamp(length(gx) + length(gy), 0.0, 3.0) * 0.5;
}

// Desenfoque de disco (espiral dorada)
vec3 discBlur(vec2 uv, float radiusPx) {
    vec3 acc = tex(uv);
    float tot = 1.0;
    for (int i = 0; i < 16; i++) {
        float fi = float(i) + 1.0;
        float a = fi * 2.399963;
        float r = sqrt(fi / 17.0) * radiusPx;
        acc += tex(uv + vec2(cos(a), sin(a)) * r * PX);
        tot += 1.0;
    }
    return acc / tot;
}

vec3 fxaa(vec2 uv) {
    vec3 rgbNW = tex(uv + PX * vec2(-1.0, -1.0));
    vec3 rgbNE = tex(uv + PX * vec2(1.0, -1.0));
    vec3 rgbSW = tex(uv + PX * vec2(-1.0, 1.0));
    vec3 rgbSE = tex(uv + PX * vec2(1.0, 1.0));
    vec3 rgbM = tex(uv);
    float lNW = luma(rgbNW), lNE = luma(rgbNE), lSW = luma(rgbSW), lSE = luma(rgbSE), lM = luma(rgbM);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    vec2 dir;
    dir.x = -((lNW + lNE) - (lSW + lSE));
    dir.y = ((lNW + lSW) - (lNE + lSE));
    float dirReduce = max((lNW + lNE + lSW + lSE) * 0.03125, 0.0078125);
    float rcp = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcp, vec2(-8.0), vec2(8.0)) * PX;
    vec3 rgbA = 0.5 * (tex(uv + dir * (1.0 / 3.0 - 0.5)) + tex(uv + dir * (2.0 / 3.0 - 0.5)));
    vec3 rgbB = rgbA * 0.5 + 0.25 * (tex(uv + dir * -0.5) + tex(uv + dir * 0.5));
    float lB = luma(rgbB);
    return (lB < lMin || lB > lMax) ? rgbA : rgbB;
}

vec3 thermalPalette(float t) {
    t = clamp(t, 0.0, 1.0);
    vec3 c = mix(vec3(0.0, 0.0, 0.25), vec3(0.4, 0.0, 0.7), smoothstep(0.0, 0.25, t));
    c = mix(c, vec3(0.9, 0.1, 0.2), smoothstep(0.25, 0.5, t));
    c = mix(c, vec3(1.0, 0.7, 0.0), smoothstep(0.5, 0.75, t));
    c = mix(c, vec3(1.0, 1.0, 0.85), smoothstep(0.75, 1.0, t));
    return c;
}

void main() {
    vec2 uv = texCoord;
    RES = vec2(textureSize(DiffuseSampler0, 0));
    PX = 1.0 / RES;
    vec2 p = uv * RES;
    float depth = texture(DiffuseDepthSampler, uv).r;
    int m = int(uMode + 0.5);
    float aspect = RES.x / RES.y;
    float t = uTime;
    vec3 col = tex(uv);

    if (m == 0) {                      // notch: 8 bits, mitad de resolucion y tramado
        vec2 q = snap(uv, 2.0);
        float d = bayer4(floor(uv * RES / 2.0)) - 0.5;
        vec3 lv = vec3(7.0, 7.0, 3.0);
        col = floor(tex(q) * lv + 0.5 + d) / lv;
    } else if (m == 1) {               // fxaa
        col = fxaa(uv);
    } else if (m == 2) {               // art: pixeles desenfocados hacia fuera, titilan
        vec2 dir = normalize(uv - 0.5 + vec2(1e-4));
        vec3 acc = vec3(0.0);
        for (int i = 0; i < 9; i++) {
            float j = 0.5 + 0.5 * h2(p + float(i) + floor(t * 20.0));
            acc += tex(uv + dir * float(i) * 0.0035 * j);
        }
        col = sat(acc / 9.0, 1.3) * 1.12;
    } else if (m == 3) {               // bumpy: relieve 3D
        float lx = luma(tex(uv + vec2(PX.x, 0.0))) - luma(tex(uv - vec2(PX.x, 0.0)));
        float ly = luma(tex(uv + vec2(0.0, PX.y))) - luma(tex(uv - vec2(0.0, PX.y)));
        vec3 n = normalize(vec3(-lx * 7.0, -ly * 7.0, 1.0));
        float lit = dot(n, normalize(vec3(-0.5, 0.7, 0.6)));
        col = col * (0.55 + 0.75 * lit);
    } else if (m == 4) {               // blobs2: manchas suaves
        vec3 b = discBlur(uv, 6.0);
        col = mix(b, floor(b * 5.0 + 0.5) / 5.0, 0.7);
        col = sat(col, 1.4);
    } else if (m == 5) {               // pencil: boceto a lapiz
        float shade = luma(col);
        float edge = sobel(uv);
        float h = step(0.5, fract((p.x + p.y) / 6.0)) * smoothstep(0.55, 0.1, shade)
                + step(0.5, fract((p.x - p.y) / 6.0)) * smoothstep(0.30, 0.0, shade);
        vec3 paper = vec3(0.93, 0.90, 0.82);
        col = paper * clamp(1.0 - 0.45 * h - 1.5 * edge, 0.0, 1.0);
    } else if (m == 6) {               // color_convolve: colores intensificados
        col = (sat(col, 2.0) - 0.5) * 1.15 + 0.5;
    } else if (m == 7) {               // deconverge: canales desalineados
        col = vec3(tex(uv + vec2(-0.004, 0.0015)).r, tex(uv).g, tex(uv + vec2(0.004, -0.0015)).b);
    } else if (m == 8) {               // flip: vista invertida verticalmente
        col = tex(vec2(uv.x, 1.0 - uv.y));
    } else if (m == 9) {               // invert
        col = vec3(1.0) - col;
    } else if (m == 10) {              // ntsc: senal de television
        float jit = 0.0006 * sin(p.y * 0.5 + t * 7.0);
        vec3 acc = vec3(0.0);
        for (int i = -5; i <= 5; i++) {
            float w = exp(-float(i * i) * 0.12);
            vec3 s = tex(uv + vec2(float(i) * PX.x * 1.5 + jit, 0.0));
            acc += vec3(luma(s), s.r - luma(s), s.b - luma(s)) * w;
        }
        acc /= 6.2;
        float yy = luma(tex(uv + vec2(jit, 0.0)));
        vec3 rgb = vec3(yy + acc.y * 1.6, 0.0, yy + acc.z * 1.6);
        rgb.g = (yy - 0.299 * rgb.r - 0.114 * rgb.b) / 0.587;
        float scan = 0.88 + 0.12 * sin(p.y * 3.14159);
        float crawl = 0.04 * sin((p.x * 0.9 + p.y * 1.4) + t * 20.0);
        col = (rgb + crawl) * scan;
    } else if (m == 11) {              // outline: contornos oscuros
        col = mix(col, vec3(0.0), smoothstep(0.15, 0.45, sobel(uv)));
    } else if (m == 12) {              // phosphor: lo gestiona la tuberia con memoria (supersecret_trail)
        col = col;
    } else if (m == 13) {              // scan_pincushion: monitor CRT
        vec2 c = uv - 0.5;
        vec2 q = 0.5 + c * (1.0 + 0.35 * dot(c, c));
        float inside = step(0.0, q.x) * step(q.x, 1.0) * step(0.0, q.y) * step(q.y, 1.0);
        float scan = 0.78 + 0.22 * sin(q.y * RES.y * 3.14159);
        col = tex(q) * scan * inside * (1.0 - 0.6 * dot(c, c));
    } else if (m == 14) {              // sobel: negro salvo los bordes
        col = vec3(clamp(sobel(uv) * 1.5, 0.0, 1.0));
    } else if (m == 15) {              // bits: baja resolucion y color de 8 bits
        vec3 lv = vec3(7.0, 7.0, 3.0);
        col = floor(tex(snap(uv, 4.0)) * lv + 0.5) / lv;
    } else if (m == 16) {              // desaturate
        col = sat(col, 0.2);
    } else if (m == 17) {              // green: CRT + bits con pantalla verde
        vec2 c = uv - 0.5;
        vec2 q = 0.5 + c * (1.0 + 0.35 * dot(c, c));
        float inside = step(0.0, q.x) * step(q.x, 1.0) * step(0.0, q.y) * step(q.y, 1.0);
        float l = floor(luma(tex(snap(q, 4.0))) * 6.0 + 0.5) / 6.0;
        float scan = 0.78 + 0.22 * sin(q.y * RES.y * 3.14159);
        col = vec3(0.12, 1.0, 0.25) * l * scan * inside * (1.0 - 0.6 * dot(c, c));
    } else if (m == 18) {              // blur
        col = discBlur(uv, 8.0);
    } else if (m == 19) {              // wobble: los colores recorren el espectro
        col = hueShift(col, t * 1.2);
    } else if (m == 20) {              // blobs: manchas pequenas cerca, grandes lejos
        float zz = 2.0 * 0.05 * uFar / (uFar + 0.05 - (depth * 2.0 - 1.0) * (uFar - 0.05));
        float rad = mix(1.5, 12.0, smoothstep(5.0, 100.0, zz));
        vec3 b = discBlur(uv, rad);
        col = sat(mix(b, floor(b * 5.0 + 0.5) / 5.0, 0.6), 1.3);
    } else if (m == 21) {              // antialias
        col = mix(fxaa(uv), discBlur(uv, 1.2), 0.25);
    } else if (m == 22) {              // creeper: baja resolucion verdosa con bordes
        vec3 b = tex(snap(uv, 6.0));
        float e = sobel(uv);
        col = vec3(0.15, 0.75, 0.2) * (0.35 + luma(b) * 0.9) + vec3(0.5, 1.0, 0.5) * e * 0.6;
    } else if (m == 23) {              // spider: muchos ojos, visual rojizo y oscuro
        vec3 acc = vec3(0.0);
        for (int i = 0; i < 6; i++) {
            float fi = float(i);
            float a = fi * 1.0472;
            vec2 eye = vec2(cos(a), sin(a)) * 0.03;
            float s = 1.0 + 0.06 * fi;
            acc += tex((uv - 0.5) * s + 0.5 + eye);
        }
        acc /= 6.0;
        acc = mix(acc, discBlur(uv, 3.0), 0.5);
        vec2 c = uv - 0.5;
        col = vec3(luma(acc) * vec3(1.2, 0.35, 0.3)) * (1.0 - 1.2 * dot(c, c));
    } else if (m == 24) {              // rainbow: todos los colores giran por el arcoiris
        col = sat(hueShift(col, t * uSpeed * 1.5), 1.4);
    } else if (m == 25) {              // rainbow_world: cada bloque cambia segun su posicion y el tiempo
        vec3 wp = screenToWorldSpace(uv, depth).xyz;
        vec3 w = (depth > 0.99999) ? normalize(wp - VeilCamera.CameraPosition) * 60.0 : wp;
        float hue = dot(w, vec3(0.04, 0.03, 0.04)) + t * 0.6 * uSpeed;
        col = sat(hueShift(col, hue * 6.2831853), 1.35);
    } else if (m == 26) {              // disco: salto de color con cada pulso
        float beat = fract(t * 4.0 * uSpeed);
        col = hueShift(col, floor(t * 4.0 * uSpeed) * 1.2566) * (0.85 + 0.5 * exp(-beat * 5.0));
    } else if (m == 27) {              // psychedelic: ondas, canales separados y colores en espiral
        vec2 c = uv - 0.5;
        float r = length(c);
        vec2 w = uv + vec2(sin(uv.y * 20.0 + t * 2.0 * uSpeed), cos(uv.x * 20.0 + t * 1.7 * uSpeed)) * 0.012
                    + normalize(c + vec2(1e-5)) * sin(r * 30.0 - t * 4.0 * uSpeed) * 0.01;
        vec3 a = vec3(tex(w + c * 0.01).r, tex(w).g, tex(w - c * 0.01).b);
        col = sat(hueShift(a, r * 8.0 + t * uSpeed), 1.5);
    } else if (m == 28) {              // thermal: camara termica
        col = thermalPalette(pow(luma(col), 0.8));
    } else if (m == 29) {              // vaporwave
        float l = luma(col);
        vec3 grad = mix(vec3(0.10, 0.0, 0.30), vec3(1.0, 0.40, 0.85), l);
        grad = mix(grad, vec3(0.2, 1.0, 0.95), smoothstep(0.7, 1.0, l));
        vec3 sh = vec3(tex(uv + vec2(0.002, 0.0)).r, col.g, tex(uv - vec2(0.002, 0.0)).b);
        col = mix(sh * vec3(1.1, 0.7, 1.2), grad, 0.5) * (0.9 + 0.1 * sin(p.y * 1.5));
    } else if (m == 30) {              // cyberpunk
        float l = luma(col);
        vec3 c2 = mix(col * vec3(0.55, 0.9, 1.25), col * vec3(1.35, 0.55, 1.1), smoothstep(0.3, 0.75, l));
        c2 = (c2 - 0.5) * 1.25 + 0.5;
        vec3 glow = max(discBlur(uv, 10.0) - 0.55, 0.0);
        col = vec3(tex(uv + vec2(0.0025, 0.0)).r, c2.g, tex(uv - vec2(0.0025, 0.0)).b) * 0.35 + c2 * 0.65 + glow * vec3(1.0, 0.3, 0.9);
    } else if (m == 31) {              // sepia
        float l = luma(col);
        col = vec3(l) * vec3(1.15, 0.95, 0.72);
    } else if (m == 32) {              // noir: blanco y negro con contraste y grano
        float l = luma(col);
        l = smoothstep(0.08, 0.92, l);
        l += (h2(p + t) - 0.5) * 0.08;
        vec2 c = uv - 0.5;
        col = vec3(l) * (1.0 - 0.9 * dot(c, c));
    } else if (m == 33) {              // cartoon: colores planos con contorno
        vec3 q = floor(sat(col, 1.3) * 5.0 + 0.5) / 5.0;
        col = mix(q, vec3(0.0), smoothstep(0.2, 0.5, sobel(uv)));
    } else if (m == 34) {              // vhs: temblor, color corrido y barra de ruido
        float line = floor(p.y);
        float jit = (h2(vec2(line, floor(t * 30.0))) - 0.5) * 0.004 * step(0.97, h2(vec2(line * 0.1, floor(t * 6.0))));
        float bar = smoothstep(0.02, 0.0, abs(fract(uv.y - t * 0.15) - 0.5) - 0.03);
        vec2 q = uv + vec2(jit + bar * 0.01, 0.0);
        vec3 a = vec3(tex(q + vec2(0.003, 0.0)).r, tex(q).g, tex(q - vec2(0.004, 0.0)).b);
        a = sat(a, 0.85) + (h2(p + t) - 0.5) * 0.12 * (1.0 + bar * 2.0);
        col = a * (0.9 + 0.1 * sin(p.y * 3.14159));
    } else if (m == 35) {              // gameboy: 4 tonos verdes con tramado
        vec2 q = snap(uv, 3.0);
        float l = luma(tex(q)) + (bayer4(floor(uv * RES / 3.0)) - 0.5) * 0.25;
        int lv = int(clamp(floor(l * 4.0), 0.0, 3.0));
        vec3 pal[4] = vec3[4](vec3(0.06, 0.22, 0.06), vec3(0.19, 0.38, 0.19), vec3(0.55, 0.67, 0.06), vec3(0.61, 0.74, 0.06));
        col = pal[lv];
    } else if (m == 36) {              // dither: 1 bit con tramado
        float l = luma(col);
        col = (l > bayer4(p)) ? vec3(0.95, 1.0, 0.9) : vec3(0.05, 0.05, 0.08);
    } else if (m == 37) {              // halftone: puntos de imprenta
        float cs = 6.0;
        float ca = 0.5236;
        mat2 rot = mat2(cos(ca), -sin(ca), sin(ca), cos(ca));
        vec2 g = rot * p / cs;
        vec2 f = fract(g) - 0.5;
        vec2 center = (transpose(rot) * ((floor(g) + 0.5) * cs)) / RES;
        vec3 c0 = tex(center);
        float rad = 0.62 * sqrt(1.0 - luma(c0) * 0.9);
        col = mix(vec3(0.97, 0.95, 0.9), sat(c0, 1.4), smoothstep(rad, rad - 0.12, length(f)));
    } else if (m == 38) {              // kaleidoscope
        vec2 q = (uv - 0.5) * vec2(aspect, 1.0);
        float a = atan(q.y, q.x) + t * 0.15 * uSpeed;
        float r = length(q);
        float seg = 6.2831853 / 6.0;
        a = abs(mod(a, seg) - seg * 0.5);
        q = r * vec2(cos(a), sin(a));
        col = tex(q / vec2(aspect, 1.0) + 0.5);
    } else if (m == 39) {              // underwater: ondulacion y tono azulado
        vec2 w = uv + vec2(sin(uv.y * 30.0 + t * 2.0), cos(uv.x * 26.0 + t * 1.6)) * 0.004;
        col = tex(w) * vec3(0.7, 1.0, 1.1);
        col = mix(col, vec3(0.05, 0.3, 0.4), 0.2);
    } else if (m == 40) {              // custom: filtro de color definido por el jugador
        vec3 c = hueShift(col, radians(uCHue));
        c = sat(c, uCSat);
        c = (c - 0.5) * uCContrast + 0.5 + uCBright;
        col = c * uCTint;
    }

    fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
    gl_FragDepth = depth;
}
