package com.example.examplemod.sss;

import com.example.examplemod.ExampleMod;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;

/** Teclas, boton en Opciones y comandos /sss. Se registra solo. */
@EventBusSubscriber(modid = ExampleMod.MODID, value = Dist.CLIENT)
public final class SssGameEvents {

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post e) {
        while (SssModEvents.NEXT.consumeClick()) SssClient.cycle(1);
        while (SssModEvents.PREV.consumeClick()) SssClient.cycle(-1);
        while (SssModEvents.OFF.consumeClick()) SssClient.set(-1);
    }

    /** Boton "Super Secret Settings..." en el menu de Opciones (Mayus + clic = filtro anterior). */
    @SubscribeEvent
    public static void onOptionsInit(ScreenEvent.Init.Post e) {
        if (!(e.getScreen() instanceof OptionsScreen)) return;
        Button b = Button.builder(Component.translatable("sss.examplemod.button"), btn -> {
            SssClient.playRandomSound();
            SssClient.cycle(Screen.hasShiftDown() ? -1 : 1);
        }).bounds(6, 6, 170, 20).build();
        e.addListener(b);
    }

    @SubscribeEvent
    public static void onCommands(RegisterClientCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("sss")
            .then(Commands.literal("next").executes(c -> { SssClient.cycle(1); return 1; }))
            .then(Commands.literal("prev").executes(c -> { SssClient.cycle(-1); return 1; }))
            .then(Commands.literal("off").executes(c -> { SssClient.set(-1); return 1; }))
            .then(Commands.literal("list").executes(c -> {
                c.getSource().sendSuccess(() -> Component.literal(String.join(", ", SssClient.MODES)), false);
                return 1;
            }))
            .then(Commands.literal("set")
                .then(Commands.argument("mode", StringArgumentType.word())
                    .suggests((c, b) -> SharedSuggestionProvider.suggest(SssClient.MODES, b))
                    .executes(c -> {
                        String name = StringArgumentType.getString(c, "mode");
                        if (!SssClient.setByName(name)) {
                            c.getSource().sendFailure(Component.literal("Filtro desconocido: " + name));
                            return 0;
                        }
                        return 1;
                    })))
            .then(Commands.literal("speed")
                .then(Commands.argument("value", FloatArgumentType.floatArg(0.1f, 10f))
                    .executes(c -> {
                        SssClient.speed = FloatArgumentType.getFloat(c, "value");
                        return 1;
                    })))
            // /sss custom <tono(-360..360)> <saturacion> <contraste> <brillo> [r g b]
            .then(Commands.literal("custom")
                .then(Commands.argument("hue", FloatArgumentType.floatArg(-360f, 360f))
                .then(Commands.argument("saturation", FloatArgumentType.floatArg(0f, 4f))
                .then(Commands.argument("contrast", FloatArgumentType.floatArg(0f, 4f))
                .then(Commands.argument("brightness", FloatArgumentType.floatArg(-1f, 1f))
                    .executes(c -> custom(c, 1f, 1f, 1f))
                    .then(Commands.argument("r", FloatArgumentType.floatArg(0f, 2f))
                    .then(Commands.argument("g", FloatArgumentType.floatArg(0f, 2f))
                    .then(Commands.argument("b", FloatArgumentType.floatArg(0f, 2f))
                        .executes(c -> custom(c,
                                FloatArgumentType.getFloat(c, "r"),
                                FloatArgumentType.getFloat(c, "g"),
                                FloatArgumentType.getFloat(c, "b")))))))))))
        );
    }

    private static int custom(com.mojang.brigadier.context.CommandContext<net.minecraft.commands.CommandSourceStack> c,
                              float r, float g, float b) {
        SssClient.cHue = FloatArgumentType.getFloat(c, "hue");
        SssClient.cSat = FloatArgumentType.getFloat(c, "saturation");
        SssClient.cContrast = FloatArgumentType.getFloat(c, "contrast");
        SssClient.cBright = FloatArgumentType.getFloat(c, "brightness");
        SssClient.cTint[0] = r;
        SssClient.cTint[1] = g;
        SssClient.cTint[2] = b;
        SssClient.set(SssClient.CUSTOM);
        return 1;
    }

    private SssGameEvents() {}
}
