package com.example.examplemod.sss;

import com.example.examplemod.ExampleMod;
import foundry.veil.api.client.render.VeilRenderSystem;
import foundry.veil.api.client.render.post.PostPipeline;
import foundry.veil.platform.VeilEventPlatform;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

import java.util.List;
import java.util.Random;

/**
 * Super Secret Settings (Minecraft 1.7.2 - 1.8.9) reimplementado sobre Veil.
 * Los 24 filtros originales van primero y en el mismo orden; despues, los filtros nuevos.
 * Es 100 % cliente: no hace falta nada en el servidor.
 */
public final class SssClient {
    public static final List<String> MODES = List.of(
            // --- originales (orden de 1.8.9) ---
            "notch", "fxaa", "art", "bumpy", "blobs2", "pencil", "color_convolve", "deconverge",
            "flip", "invert", "ntsc", "outline", "phosphor", "scan_pincushion", "sobel", "bits",
            "desaturate", "green", "blur", "wobble", "blobs", "antialias", "creeper", "spider",
            // --- nuevos ---
            "rainbow", "rainbow_world", "disco", "psychedelic", "thermal", "vaporwave", "cyberpunk",
            "sepia", "noir", "cartoon", "vhs", "gameboy", "dither", "halftone", "kaleidoscope",
            "underwater", "custom");

    private static final int PHOSPHOR = MODES.indexOf("phosphor");
    public static final int CUSTOM = MODES.indexOf("custom");

    private static final ResourceLocation PIPE = ResourceLocation.fromNamespaceAndPath(ExampleMod.MODID, "supersecret");
    private static final ResourceLocation TRAIL = ResourceLocation.fromNamespaceAndPath(ExampleMod.MODID, "supersecret_trail");
    private static final long START = System.nanoTime();
    private static final Random RANDOM = new Random();

    private static int index = -1;
    private static boolean initialized = false;

    // ajustes editables con /sss
    public static float speed = 1f;
    public static float cHue = 0f, cSat = 1f, cContrast = 1f, cBright = 0f;
    public static final float[] cTint = {1f, 1f, 1f};

    public static int current() {
        return index;
    }

    private static void ensureInit() {
        if (initialized) return;
        initialized = true;
        VeilEventPlatform.INSTANCE.preVeilPostProcessing((name, pipeline, ctx) -> {
            if (name.equals(PIPE)) applyUniforms(pipeline);
        });
    }

    /** dir = +1 siguiente, -1 anterior. Despues del ultimo filtro vuelve a "desactivado". */
    public static void cycle(int dir) {
        int n = MODES.size() + 1;
        set(Math.floorMod(index + 1 + dir, n) - 1);
    }

    public static boolean setByName(String name) {
        int i = MODES.indexOf(name);
        if (i < 0) return false;
        set(i);
        return true;
    }

    public static void set(int newIndex) {
        index = newIndex;
        ensureInit();
        var pm = VeilRenderSystem.renderer().getPostProcessingManager();
        if (pm.isActive(PIPE)) pm.remove(PIPE);
        if (pm.isActive(TRAIL)) pm.remove(TRAIL);
        Component msg;
        if (index >= 0) {
            pm.add(index == PHOSPHOR ? TRAIL : PIPE);
            msg = Component.translatable("sss.examplemod.status", index + 1,
                    Component.translatable("sss.examplemod.mode." + MODES.get(index)));
        } else {
            msg = Component.translatable("sss.examplemod.off");
        }
        Minecraft.getInstance().gui.setOverlayMessage(msg, false);
    }

    /** El sonido aleatorio de mob que sonaba al pulsar el boton original. */
    public static void playRandomSound() {
        SoundEvent[] s = {SoundEvents.PIG_AMBIENT, SoundEvents.COW_AMBIENT, SoundEvents.CHICKEN_AMBIENT,
                SoundEvents.SHEEP_AMBIENT, SoundEvents.VILLAGER_YES, SoundEvents.ZOMBIE_AMBIENT};
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(s[RANDOM.nextInt(s.length)], 1.0f));
    }

    private static void applyUniforms(PostPipeline pl) {
        Minecraft mc = Minecraft.getInstance();
        pl.getUniformSafe("uMode").setFloat(index);
        pl.getUniformSafe("uTime").setFloat((System.nanoTime() - START) / 1.0e9f);
        pl.getUniformSafe("uFar").setFloat(mc.gameRenderer.getDepthFar());
        pl.getUniformSafe("uSpeed").setFloat(speed);
        pl.getUniformSafe("uCHue").setFloat(cHue);
        pl.getUniformSafe("uCSat").setFloat(cSat);
        pl.getUniformSafe("uCContrast").setFloat(cContrast);
        pl.getUniformSafe("uCBright").setFloat(cBright);
        pl.getUniformSafe("uCTint").setVector(cTint[0], cTint[1], cTint[2]);
    }

    private SssClient() {}
}
