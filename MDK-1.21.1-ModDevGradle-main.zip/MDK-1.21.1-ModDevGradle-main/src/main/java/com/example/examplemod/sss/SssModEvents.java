package com.example.examplemod.sss;

import com.example.examplemod.ExampleMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;

/** Teclas (se pueden cambiar en Controles). Se registra solo. */
@EventBusSubscriber(modid = ExampleMod.MODID, value = Dist.CLIENT)
public final class SssModEvents {
    private static final String CAT = "key.categories.examplemod";

    public static final KeyMapping NEXT = new KeyMapping("key.examplemod.sss_next",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F4, CAT);
    public static final KeyMapping PREV = new KeyMapping("key.examplemod.sss_prev",
            InputConstants.Type.KEYSYM, InputConstants.UNKNOWN.getValue(), CAT);
    public static final KeyMapping OFF = new KeyMapping("key.examplemod.sss_off",
            InputConstants.Type.KEYSYM, InputConstants.UNKNOWN.getValue(), CAT);

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(NEXT);
        e.register(PREV);
        e.register(OFF);
    }

    private SssModEvents() {}
}
